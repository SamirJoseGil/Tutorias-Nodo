package nodo.aztro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AztroApplication {

	public static void main(String[] args) {
		SpringApplication.run(AztroApplication.class, args);
	}

}
