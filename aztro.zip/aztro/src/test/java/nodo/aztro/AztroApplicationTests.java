package nodo.aztro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AztroApplicationTests {

	@Test
	void contextLoads() {
	}

}
